Project Name - Explore US Bikeshare Data
Programming for Data science with python
Junaid Salahuddin


Helping Source:

https://stackoverflow.com/questions/21323692/convert-seconds-to-weeks-days-hours-minutes-seconds-in-python

http://pandas.pydata.org/pandas-docs/stable/api.html?#groupby

https://www.shanelynn.ie/summarising-aggregation-and-grouping-data-in-python-pandas/

https://docs.python.org/3/tutorial/inputoutput.html

https://www.programiz.com/python-programming/methods/string/rjust
